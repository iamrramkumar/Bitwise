package com.example.bitwise;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    EditText email,pass;
    String mail,pwd;
    Button signin,register;
    Boolean log1=false,log2=false,log3=false;
    private FirebaseAuth firebaseAuth;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signin=findViewById(R.id.signin);
        register=findViewById((R.id.register));
        pass=findViewById(R.id.pwd);
        email=findViewById((R.id.email));

        firebaseAuth = FirebaseAuth.getInstance();
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mail=email.getText().toString();
                pwd=pass.getText().toString();
                if (mail.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                    email.setError("enter a valid email address");
                    log1=false;
                }
                else{
                    log1=true;
                }

                if(!pwd.isEmpty()){
                    log2=true;
                }else {
                    log2=false;
                    pass.setError("Enter valid Password");
                }
                Boolean log=log1&&log2;
                if(log.equals(true)){
                   /* Intent i =new Intent(MainActivity.this,Video.class);
                    startActivity(i);*/
                    //signin();
                    //
                    userregister();
                }
            }
        });
        signin.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                mail=email.getText().toString();
                pwd=pass.getText().toString();
                if (mail.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                    email.setError("enter a valid email address");
                    log1=false;
                }
                else{
                    log1=true;
                }

                if(pwd.equals("123abc")){
                    log2=true;
                }else {
                    log2=false;
                    pass.setError("Enter valid Password");
                }
                Boolean log=log1&&log2;
                if(log.equals(true)){
                   /* Intent i =new Intent(MainActivity.this,Video.class);
                    startActivity(i);*/
                    signin();
                    //


                }
            }
            });

        }


    private void signin() {
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Signing in....");
        progressDialog.show();
        if (mail.isEmpty() || pwd.isEmpty()) {
            Toast.makeText(getApplicationContext(), "Unsuccessful,Fields are empty.",
                    Toast.LENGTH_LONG).show();
            progressDialog.hide();
        }
        else {
            firebaseAuth.signInWithEmailAndPassword(mail,pwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), "Welcome "+email,
                                Toast.LENGTH_LONG).show();
                        startActivity(new Intent(MainActivity.this,Video.class));
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Sign in Error",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });

        }
    }

    private void userregister() {
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Registering....");
        progressDialog.show();

        if(mail.isEmpty()||pwd.isEmpty()){
            Toast.makeText(getApplicationContext(), "Unsuccessful, Fields are empty.",
                    Toast.LENGTH_LONG).show();
            progressDialog.hide();
        }
        else {
            progressDialog.hide();
            firebaseAuth.createUserWithEmailAndPassword(mail, pwd).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), "Registration Successful",
                                Toast.LENGTH_LONG).show();
                        email.setText("");
                        pass.setText("");
                    } else {
                        Toast.makeText(getApplicationContext(), "Registration Unsuccessful",
                                Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }
}